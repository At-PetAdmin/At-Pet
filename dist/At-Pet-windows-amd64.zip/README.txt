At-Pet for Windows amd64

Built for Windows 10/11 on x86-64. Qt and the MinGW runtime are bundled, so no Qt installation is required.
Start at-pet.exe. The local API listens on 127.0.0.1:8765 unless AT_PET_PORT is set.
