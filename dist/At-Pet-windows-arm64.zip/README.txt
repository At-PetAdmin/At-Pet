At-Pet for Windows ARM64

Built for Windows 10/11 on ARM64.
If the Microsoft Visual C++ ARM64 Redistributable is not installed, run vc_redist.arm64.exe first.
Then start at-pet.exe.
